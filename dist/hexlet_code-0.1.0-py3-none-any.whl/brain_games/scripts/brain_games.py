#!/usr/bin/env python3

def welcoming():
    print('Welcome to the Brain Games!')

def main():
    welcoming()

if __name__ == '__main__':
    main()
