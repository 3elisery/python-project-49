### Hexlet tests and linter status:
[![Actions Status](https://github.com/3elisery/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/3elisery/python-project-49/actions)

### Maintainability badge from CodeClimate
[![Maintainability](https://api.codeclimate.com/v1/badges/ac1fab85624385228bd5/maintainability)](https://codeclimate.com/github/3elisery/python-project-49/maintainability)